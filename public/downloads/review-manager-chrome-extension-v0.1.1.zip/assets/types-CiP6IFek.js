const S="collection-status",A="COLLECTION_STATUS_CHANGED",E=20;export{E as M,S,A as a};
//# sourceMappingURL=types-CiP6IFek.js.map
