import './assets/service-worker.ts-BG881-QO.js';
